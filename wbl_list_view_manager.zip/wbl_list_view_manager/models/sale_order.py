from odoo import models, fields, api
from lxml import etree
import logging

_logger = logging.getLogger(__name__)

class SaleOrder(models.Model):
    # _inherit = 'sale.order'
    _inherit = 'res.partner'

    @api.model
    def get_sale_order_fields(self):
        fields = []
        for field_name, field in self._fields.items():
            if field.type not in ['binary', 'html']:
                fields.append({
                    "id": field_name,
                    "string": field.string or field_name,
                    "type": field.type,
                })
        print(fields)
        return fields


