from odoo import models, fields, api
from odoo import http
from odoo.http import request
from odoo.service.model import call_kw
from odoo.service.server import thread_local


class SaleOrder(models.Model):
    _inherit = 'sale.order'
