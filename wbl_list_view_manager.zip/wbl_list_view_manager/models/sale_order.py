from odoo import models, fields, api


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    @api.model
    def get_sale_order_fields(self):
        fields = []

        for field_name, field in self._fields.items():
            if field.type not in ['boolean', 'binary']:
                fields.append({
                    "id": field_name,
                    "string": field.string or field_name,
                    "type": field.type
                })
        return fields




    # @api.model
    # def fields_to_show(self):
    #     # Backend se dynamic fields decide karo
    #     return ["id", "carrier_id","activity_user_id", "activity_summary", "amount_total"]
    #
    # @api.model
    # def create_dynamic_tree_view(self):
    #     fields = self.fields_to_show()
    #
    #     field_xml = "".join([f"<field name=\"{f}\"/>" for f in fields])
    #
    #     view = self.env.ref("sale.view_quotation_tree_with_onboarding")
    #     view.arch = f"""<list>{field_xml}</list>
    #         """
