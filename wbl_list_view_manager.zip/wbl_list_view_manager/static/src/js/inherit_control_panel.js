/** @odoo-module **/
import { patch } from "@web/core/utils/patch";
import { rpc } from "@web/core/network/rpc";
import { domainFromTree } from "@web/core/tree_editor/domain_from_tree";
import { SearchBar } from "@web/search/search_bar/search_bar";
import { SearchModel } from "@web/search/search_model";
import { ControlPanel } from "@web/search/control_panel/control_panel";
import { ListRenderer } from "@web/views/list/list_renderer";
import { Component, useState, onMounted,onWillStart, useRef, useEffect, onWillRender } from "@odoo/owl";
import { browser } from "@web/core/browser/browser";
import { listView } from '@web/views/list/list_view';
import { ListController } from '@web/views/list/list_controller';
import { busService } from "@bus/services/bus_service";
import { useAutofocus, useBus, useService } from "@web/core/utils/hooks";


patch(ControlPanel.prototype, {

    setup() {
        super.setup();
        this.activeFields = new Set();

        onWillStart(async () => {
            const saved = JSON.parse(browser.localStorage.getItem('activeFields')) || [];
            this.activeFields = new Set(saved);
        });
//
    },

//    async onSaveFields() {
//        await rpc("/web/dataset/call_kw/sale.order/create_dynamic_tree_view", {
//            model: "sale.order",
//            method: "create_dynamic_tree_view",
//            args: [],
//            kwargs: {},
//        });
//        console.log("cll")
//        window.location.reload();
//        this.render();
//    },



    async loadSaleOrderFields() {
        const result = await rpc("/web/dataset/call_kw/sale.order/get_sale_order_fields", {
            model: "sale.order",
            method: "get_sale_order_fields",
            args: [],
            kwargs: {},
        });
        console.log("Fields from backend:", result);
        this.fieldsArray = result;
        this.render();
    },



    onFieldToggle(ev) {
        const fieldId = ev.target.name;
        if (ev.target.checked) {
            this.activeFields.add(fieldId);
        } else {
            this.activeFields.delete(fieldId);
        }
        browser.localStorage.setItem('activeFields', JSON.stringify([...this.activeFields]));
//        this.onSaveFields();
//        this.render();
    },


});

