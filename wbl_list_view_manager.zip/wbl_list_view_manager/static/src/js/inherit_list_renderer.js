/** @odoo-module **/
import { ListRenderer } from "@web/views/list/list_renderer";
import { patch } from "@web/core/utils/patch";
import { Component, onMounted, useRef } from "@odoo/owl";
import { rpc } from "@web/core/network/rpc";
import { domainFromTree } from "@web/core/tree_editor/domain_from_tree";
import { SearchBar } from "@web/search/search_bar/search_bar";

patch(ListRenderer.prototype, {

    setup(){
        super.setup();

        this.env.searchModel.isHideFilterOnUI = false;

        this.StateObj = {
            'Sales Order':'sale',
            'Quotation':'draft',
            'Quotation Sent':'sent',
            'Cancelled' : 'cancel'
            };

        this.InvoiceStatusObj = {
            'Nothing to Invoice':'no',
            'To Invoice':'to invoice',
            'Fully Invoiced':'invoiced',
            'Upselling' : 'Upselling Opportunity'
            };

        this.DeliveryStatusObj = {
            'Not Delivered':'pending',
            'Started':'started',
            'Partially Delivered':'partial',
            'Fully Delivered' : 'full'
            };

    },

    // This Fun used for Hide SerachBar Filter on UI.
    isHideFilterOnUI(){

        this.env.searchModel.isHideFilterOnUI = true
    },

    // This Fun used for Show
    get isShowModels() {
        return this.props.list.resModel === 'sale.order' ||
               this.props.list.resModel === 'product.template'
    },


    getColumns(_record) {

        return this.columns;
    },

    onFilterInputChange(ev) {
        const value = ev.target.value;
        const columnName = ev.target.dataset.column;
        const rangeType = ev.target.dataset.range;

        if (!this.filters) {
            this.filters = {};
        }

        if (rangeType) {
            if (!this.filters[columnName]) {
                this.filters[columnName] = {};
            }
            this.filters[columnName][rangeType] = value;
        } else {
            this.filters[columnName] = value;
        }

        console.log(" ACTIVE FILTERS:", this.filters);

        const domain = this.buildDomainFromFilters(this.filters);

        this.applyUserFilters(domain)
    },


    buildDomainFromFilters(filters) {
        const domain = [];
        console.log("builddoamin", domain)

        for (const field in filters) {
            const value = filters[field];

            if (typeof value === "object") {
                if (value.min) {
                    domain.push([field, ">=", value.min]);
                }
                if (value.max) {
                    domain.push([field, "<=", value.max]);
                }
            }
            else {
                if (value !== "" && value !== null && value !== undefined) {
                    domain.push([field, "ilike", value]);
                }
            }
        }
        return domain;
    },


    async applyUserFilters(domain) {

        const tree = await this.env.searchModel.treeProcessor.treeFromDomain(
            this.env.searchModel.resModel,
            domain,
            true
        );

        const [description, tooltip] = await Promise.all([
            this.env.searchModel.treeProcessor.getDomainTreeDescription(
                this.env.searchModel.resModel,
                tree
            ),
            this.env.searchModel.treeProcessor.getDomainTreeTooltip(
                this.env.searchModel.resModel,
                tree
            ),
        ]);

        const preFilter = {
            description: "",
            tooltip: "",
            domain: domainFromTree(tree),
            invisible: "True",
            type: "filter",
        };

        this.env.searchModel.createNewFilters([preFilter]);

        this.env.searchModel.deactivateGroup((preFilter.groupId) -1); // ye abhi just testing ke liye baad me thik krunga isko.

        await this.env.searchModel._notify();
        this.isHideFilterOnUI()
    },







//    getRowClass(record) {
//        const base = super.getRowClass(record) || "";
//        const classes = [base];
////        console.log("all data:", record.data);
//
//        if (this.filters) {
//            let hide = false;
//
//            for (const col in this.filters) {
//                const filterVal = this.filters[col];
////                console.log("Checking column:", col, typeof col);
////                console.log("Filter value:", filterVal, typeof filterVal);
//
//                if (record.data[col] && typeof record.data[col] === 'object') {
//                    console.log("if condition called")
//
//                    if (col === 'tag_ids'){
//                        console.log("super if inside if condition")
//
//                        const staticListValue = record.data[col];
//                        const allDisplayNames = staticListValue.records.map(r => {
//                            return r.data.display_name;
//                        });
//
//                        console.log("All Display Names:", allDisplayNames);
//                        // output = ['Product', 'Services', 'Information'] array aata hs isme yrr
//
//                        const filterString = String(filterVal).toLowerCase();
//
//                        if (!filterString) {
//                            hide = false;
//                        } else {
//                            const isMatch = allDisplayNames.some(displayName => {
//                                const nameString = String(displayName || '').toLowerCase();
//                                return nameString.includes(filterString);
//                            });
//                            if (!isMatch) {
//                                hide = true;
//                            } else {
//                                hide = false;
//                            }
//                        }
//
//                    }
//
//                    else if (["date_order", "validity_date", "commitment_date", "expected_date"].includes(col)){
//                        console.log("Date-Only Filter Applied (Normalized Native Date) for:", col);
//
//                        const recordDateTime = record.data[col];
//                        let recordTs = null;
//
//                        if (recordDateTime instanceof Date) {
//                            recordDateTime.setHours(0, 0, 0, 0);
//                            recordTs = recordDateTime.getTime();
//                        } else if (recordDateTime && typeof recordDateTime.ts === 'number') {
//                            const dateFromTs = new Date(recordDateTime.ts);
//                            dateFromTs.setHours(0, 0, 0, 0);
//                            recordTs = dateFromTs.getTime();
//                        }
//
//                        console.log("Normalized Record Date Timestamp (ms):", recordTs);
//
//                        if (recordTs === null || isNaN(recordTs)) {
//                            hide = true;
//                            return;
//                        }
//
//
//                        const minInput = filterVal.min;
//                        const maxInput = filterVal.max;
//
//                        let minTs = null;
//                        let maxTs = null;
//
//                        if (minInput) {
//                            const minDate = new Date(minInput);
//                            minDate.setHours(0, 0, 0, 0);
//                            if (!isNaN(minDate.getTime())) {
//                                minTs = minDate.getTime();
//                            }
//                        }
//
//                        if (maxInput) {
//                            const maxDate = new Date(maxInput);
//                            maxDate.setHours(0, 0, 0, 0);
//
//                            if (!isNaN(maxDate.getTime())) {
//                                maxTs = maxDate.getTime();
//                            }
//                        } else {
//                            // ✅ नया लॉजिक: यदि maxInput नहीं दिया गया है, तो आज की तारीख का उपयोग करें
//                            const today = new Date();
//                            today.setHours(0, 0, 0, 0); // आज को 00:00:00 पर सेट करें
//                            maxTs = today.getTime();
//                            console.log("Max date not provided. Defaulting to start of today:", new Date(maxTs));
//                        }
//
//
//                        if (minTs !== null && recordTs < minTs) {
//                            console.log("Hidden: Record is before min date.");
//                            hide = true;
//                        }
//
//                        else if (maxTs !== null && recordTs > maxTs) {
//                            console.log("Hidden: Record is after max date (i.e., tomorrow or later).");
//                            hide = true;
//                        }
//
//                        else {
//                            console.log("Visible: Record is within the range.");
//                            hide = false;
//                        }
//                    }
//
//                    else if (col === 'activity_ids'){
//                        console.log("Direct Activity Summary Filter Applied for:", col);
//
//                        const recVal = record.data.activity_summary;
//                        const filterString = String(filterVal || '').toLowerCase().trim();
//
//                        console.log("Record Summary:", recVal, "| Filter String:", filterString);
//
//                        if (!filterString) {
//                            hide = false;
//                        } else {
//                            const summary = String(recVal || '').toLowerCase();
//
//                            if (!summary.includes(filterString)) {
//                                hide = true;
//                                console.log("Hidden: Activity Summary does not contain filter.");
//                            } else {
//                                hide = false;
//                                console.log("Visible: Activity Summary matches filter.");
//                            }
//                        }
//                    }
//
//                    else {
//                        const recVal = record.data[col].display_name || record.data[col].id;
//                        console.log("recVal for M2O field:", recVal);
//
//                        if (recVal === false || recVal === undefined) {
//                            hide = true;
//                        } else {
//                            if (!String(recVal).toLowerCase().includes(String(filterVal).toLowerCase())) {
//                                hide = true;
//                            }
//                        }
//                    }
//
//                }
//
//                else if (typeof filterVal === "object") {
//                    console.log("elsif condition")
//                    const min = filterVal.min ? parseFloat(filterVal.min) : null;
//                    const max = filterVal.max ? parseFloat(filterVal.max) : null;
//                    const recVal = parseFloat(record.data[col] || 0);
//
//                    if (min !== null && recVal < min) hide = true;
//                    if (max !== null && recVal > max) hide = true;
//                }
//
//                else {
//                    console.log("else condition")
//                    const recVal = record.data[col];
//
//                    if (recVal === false || recVal === undefined) {
//                        hide = true;
//                    } else {
//                        if (!String(recVal).toLowerCase().includes(String(filterVal).toLowerCase())) {
//                            hide = true;
//                        }
//                    }
//                }
//            }
//
//            if (hide) {
//                classes.push("hide-row");
//            }
//        }
//        return classes.join(" ");
//    },



});