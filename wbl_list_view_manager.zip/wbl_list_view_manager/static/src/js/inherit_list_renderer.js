/** @odoo-module **/
import { ListRenderer } from "@web/views/list/list_renderer";
import { patch } from "@web/core/utils/patch";
import { Component, onMounted, useRef } from "@odoo/owl";
import { rpc } from "@web/core/network/rpc";
import { domainFromTree } from "@web/core/tree_editor/domain_from_tree";
import { SearchBar } from "@web/search/search_bar/search_bar";
import { SearchModel } from "@web/search/search_model";
import { useBus } from "@web/core/utils/hooks";


patch(ListRenderer.prototype, {

    setup(){
        super.setup();

        this.StateObj = {
            'Sales Order':'sale',
            'Quotation':'draft',
            'Quotation Sent':'sent',
            'Cancelled' : 'cancel'
            };

        this.InvoiceStatusObj = {
            'Nothing to Invoice':'no',
            'To Invoice':'to invoice',
            'Fully Invoiced':'invoiced',
            'Upselling' : 'Upselling Opportunity'
            };

        this.DeliveryStatusObj = {
            'Not Delivered':'pending',
            'Started':'started',
            'Partially Delivered':'partial',
            'Fully Delivered' : 'full'
            };



    },

    get isShowModels() {
        return this.props.list.resModel === 'sale.order' ||
               this.props.list.resModel === 'product.template'
    },

    getColumns(_record) {

        return this.columns;
    },

    onFilterInputChange(ev) {
        const value = ev.target.value;
        const columnName = ev.target.dataset.column;
        const rangeType = ev.target.dataset.range;

        if (!this.filters) {
            this.filters = {};
        }

        if (rangeType) {
            if (!this.filters[columnName]) {
                this.filters[columnName] = {};
            }
            this.filters[columnName][rangeType] = value;
        } else {
            this.filters[columnName] = value;
        }

        console.log(" ACTIVE FILTERS:", this.filters);

        const domain = this.buildDomainFromFilters(this.filters);

        this.applyUserFilters(domain)
    },

    buildDomainFromFilters(filters) {
        const domain = [];
        console.log("builddoamin", domain)

        for (const field in filters) {
            const value = filters[field];

            if (typeof value === "object") {
                if (value.min) {
                    domain.push([field, ">=", value.min]);
                }
                if (value.max) {
                    domain.push([field, "<=", value.max]);
                }
            }
            else {
                if (value !== "" && value !== null && value !== undefined) {
                    domain.push([field, "ilike", value]);
                }
            }
        }
        return domain;
    },

    async applyUserFilters(domain) {

        const tree = await this.env.searchModel.treeProcessor.treeFromDomain(
            this.env.searchModel.resModel,
            domain,
            true
        );

        const [description, tooltip] = await Promise.all([
            this.env.searchModel.treeProcessor.getDomainTreeDescription(
                this.env.searchModel.resModel,
                tree
            ),
            this.env.searchModel.treeProcessor.getDomainTreeTooltip(
                this.env.searchModel.resModel,
                tree
            ),
        ]);

        const preFilter = {
            name: "Custom Filter",
            title: "Custom Filter",
            description: "Custom Filter",
            domain: domainFromTree(tree),
            invisible: "True",
            type: "filter",
            groupId: 1000,
        };

        this.env.searchModel.createNewFilters([preFilter]);

        this.env.searchModel.deactivateGroup((preFilter.groupId) -1);

        await this.env.searchModel._notify();
    },


});