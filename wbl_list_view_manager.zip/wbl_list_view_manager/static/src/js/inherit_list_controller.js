/** @odoo-module **/
import { patch } from "@web/core/utils/patch";
import { rpc } from "@web/core/network/rpc";
import { domainFromTree } from "@web/core/tree_editor/domain_from_tree";
import { SearchBar } from "@web/search/search_bar/search_bar";
import { SearchModel } from "@web/search/search_model";
import { ControlPanel } from "@web/search/control_panel/control_panel";
import { ListRenderer } from "@web/views/list/list_renderer";
import { Component, useState, onMounted, useRef, useEffect, onWillRender } from "@odoo/owl";
import { ListController } from "@web/views/list/list_controller";
import { busService } from "@bus/services/bus_service";
import { useAutofocus, useBus, useService } from "@web/core/utils/hooks";


patch(ListController.prototype,{
    setup() {
        super.setup();

    },


});