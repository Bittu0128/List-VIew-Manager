/** @odoo-module **/
import { patch } from "@web/core/utils/patch";
import { rpc } from "@web/core/network/rpc";
import { domainFromTree } from "@web/core/tree_editor/domain_from_tree";
import { SearchBar } from "@web/search/search_bar/search_bar";
import { SearchModel } from "@web/search/search_model";
import { ControlPanel } from "@web/search/control_panel/control_panel";
import { ListRenderer } from "@web/views/list/list_renderer";
import { Component, useState, onMounted, useRef, useEffect, onWillRender } from "@odoo/owl";
import { ListController } from "@web/views/list/list_controller";

patch(ListController.prototype, {

//    async onMounted() {
//        await super.onMounted();
//
//        console.log("ListController mounted!");
//
//        const groups = this.renderer.getOptionalFieldGroups();
//        console.log("Groups:", groups);
//
//        // 🔥 SEARCH MODEL ko event send karo
//        this.model.searchModel.trigger("optional-field-groups-ready", groups);
//    },

});
