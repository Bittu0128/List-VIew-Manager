/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { _t } from "@web/core/l10n/translation";
import { SearchBar } from "@web/search/search_bar/search_bar";
import { SearchModel } from "@web/search/search_model";

patch(SearchBar.prototype, {
    setup(){
        super.setup();

    },




});



patch(SearchModel.prototype, {




});