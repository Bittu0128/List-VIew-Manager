from werkzeug.exceptions import NotFound
from odoo import http, models
from odoo.http import request
from odoo.service.model import call_kw
from odoo.service.server import thread_local
from odoo.addons.web.controllers.dataset import DataSet


# from .utils import clean_action


class CustomerDataSet(DataSet):
    pass

    # def _call_kw_readonly(self, rule, args):
    #     params = request.get_json_data()['params']
    #     try:
    #         model_class = request.registry[params['model']]
    #     except KeyError as e:
    #         raise NotFound() from e
    #     method_name = params['method']
    #     for cls in model_class.mro():
    #         method = getattr(cls, method_name, None)
    #         if method is not None and hasattr(method, '_readonly'):
    #             return method._readonly
    #     return False

    # @http.route('/web/dataset/call_kw/customer.dataset/get_filtered_data',
    #             type='json',
    #             auth="user",
    #             methods=['POST'])
    # def get_filtered_data(self, model, method, args, kwargs):
    #
    #     filters = args[0] if args else {}
    #
    #     print("🔥 Backend received filters:", filters)
    #     # thread_local.customer_filters = filters
    #
    #     return filters


    # @http.route(['/web/dataset/call_kw', '/web/dataset/call_kw/<path:path>'], type='jsonrpc', auth="user",
    #             readonly=DataSet._call_kw_readonly)
    # def call_kw(self, model, method, args, kwargs, path=None):
    #
    #     filters = getattr(thread_local, 'customer_filters', None)
    #     ans = self.get_filtered_data(model, method, args, kwargs)
    #     print("my bittu kumar", ans)
    #     print("📌 Filters loaded inside call_kw:", filters)
    #
    #     res = super().call_kw(model, method, args, kwargs, path)

        # if model == 'sale.order':
        #     if isinstance(res, dict) and 'records' in res:
        #
        #         filtered_records = [
        #             record
        #             for record in res['records']
        #             if record.get('state') == 'sale'
        #         ]
        #         if filtered_records:
        #
        #             res['records'] = filtered_records
        #             res['length'] = len(filtered_records)
        #
        #
        #         else:
        #             res['records'] = []
        #             res['length'] = 0
        #             print("ID 39 Not Found.")
        # return res


